import express from 'express';
import { sequelize } from './model/modelos.js';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import dotenv from 'dotenv';
import router from './router/router.js'; // Importação das rotas

dotenv.config();

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
const dbPath = path.resolve(__dirname, './database.sqlite');
app.use('/', router);
const PORT = process.env.PORT || 3000;

// Função para inicializar o banco de dados
async function initDatabase() {
  try {
    // Sincroniza o banco de dados
    await sequelize.sync();
    console.log('Banco de dados sincronizado com sucesso.');

    // Inicia o servidor após o banco estar sincronizado
    app.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Erro ao inicializar o banco de dados:', error);
  }
}

initDatabase();

console.log("Configuração do Sequelize:", {
  dialect: sequelize.getDialect(),
  storage: sequelize.options.storage,
});
  
import { Sequelize } from "sequelize";
import dotenv from "dotenv";

//Comando pra dar start: npm run start:dev (SQLite) ou npm run start:prod (Postgres)

dotenv.config();

const alternativo = process.env.NODE_ENV === "production";

const sequelize = new Sequelize(
    alternativo ? process.env.DB_PROD_NAME : null,
    alternativo ? process.env.DB_PROD_USER : null,
    alternativo ? process.env.DB_PROD_PASSWORD : null,
    {
        host: alternativo ? process.env.DB_PROD_HOST : undefined,
        port: alternativo ? process.env.DB_PROD_PORT : undefined,
        dialect: alternativo ? process.env.DB_PROD_DIALECT : process.env.DB_DEV_DIALECT,
        storage: !alternativo ? process.env.DB_DEV_STORAGE : undefined,
        dialectOptions: alternativo
            ? {
                ssl: {
                    require: true,
                    rejectUnauthorized: false,
                },
            }
            : undefined,
        logging: false,
    }
);

sequelize.sync( )
  .then(() => {
    console.log("Sincronização concluída.");
    console.log("Caminho do banco de dados:", sequelize.options.storage);
  })
  .catch((err) => {
    console.error("Erro durante a sincronização:", err);
  });

export default sequelize;
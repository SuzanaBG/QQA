import sequelize from "./database.js";  // Importando do arquivo database.js
import { DataTypes, Model } from "sequelize";
import Usuario from "./Usuarios.js";
import Seguidores from "./Seguidores.js";
import Publicacoes from "./Publicacoes.js";
import Comentarios from "./Comentarios.js";

Seguidores.belongsTo(Usuario, { foreignKey: "usuario_id" });
Seguidores.belongsTo(Usuario, { foreignKey: "seguidor_id" });
Publicacoes.belongsTo(Usuario, { foreignKey: "usuario_id" });
Comentarios.belongsTo(Usuario, { foreignKey: "usuario_id" });
Comentarios.belongsTo(Publicacoes, { foreignKey: "publicacao_id" });

Usuario.hasMany(Publicacoes, { foreignKey: "usuario_id" });
Usuario.hasMany(Comentarios, { foreignKey: "usuario_id" });
Publicacoes.hasMany(Comentarios, { foreignKey: "publicacao_id" });

export { sequelize, DataTypes, Model, Usuario, Seguidores, Publicacoes, Comentarios };

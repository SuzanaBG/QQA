import { DataTypes, Model } from "sequelize";
import sequelize from "./database.js";
import { v4 as uuidv4 } from "uuid";

class Publicacoes extends Model {}

Publicacoes.init(
  {
    id: {
      type: DataTypes.STRING,
      defaultValue: () => uuidv4(),
      primaryKey: true,
      allowNull: false,
    },
    usuario_id: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    publicacao: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    qtd_likes: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
      allowNull: false,
    },
    criado_em: {
      type: DataTypes.DATE,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      allowNull: false,
    }
  },
  {
    sequelize,
    modelName: "Publicacoes",
    timestamps: false,
  }
);

export default Publicacoes;

import sqlite3 from 'sqlite3';
import { Usuario, Publicacoes, Comentarios, Seguidores } from "../model/modelos.js";

import { v4 as uuidv4 } from "uuid";

//Iniciando o Banco de dados local
const db = new sqlite3.Database('./database.sqlite', (err) => {
  if (err) {
    console.error('Erro ao abrir o banco de dados', err);
  } else {
    console.log('Banco de dados aberto com sucesso');
  }
});

const controller = {};

//Comentado Arrumado
controller.usuario = async (req, res) => {
    const data = req.body;
  
    if (!data.nome || !data.email || !data.senha || !data.nascimento || !data.nick) {
      return res.status(400).json({
        erro: 'Todos os campos são obrigatórios',
        detalhes: data
      });
    }
  
    const [year, month, day] = data.nascimento.split('-');
    data.nascimento = `${year}-${month}-${day}`;
  
    const nascimento = new Date(data.nascimento);
    const hoje = new Date();
    let idade = hoje.getFullYear() - nascimento.getFullYear();
    const m = hoje.getMonth() - nascimento.getMonth();
  
    if (m < 0 || (m === 0 && hoje.getDate() < nascimento.getDate())) {
      idade--;
    }
  
    if (idade < 16) {
      return res.status(400).json({
        erro: 'A idade deve ser maior que 16 anos'
      });
    }
  
    try {
      const emailExists = await new Promise((resolve, reject) => {
        db.get('SELECT email FROM Usuarios WHERE email = ?', [data.email], (err, row) => {
          if (err) reject(err);
          resolve(row);
        });
      });
  
      if (emailExists) {
        return res.status(400).json({ erro: 'Email já está em uso' });
      }
  
      const nickExists = await new Promise((resolve, reject) => {
        db.get('SELECT nick FROM Usuarios WHERE nick = ?', [data.nick], (err, row) => {
          if (err) reject(err);
          resolve(row);
        });
      });
  
      if (nickExists) {
        return res.status(400).json({ erro: 'Nick já está em uso' });
      }
      const id = uuidv4();
      db.run(
        'INSERT INTO Usuarios (id, nome, email, senha, nascimento, nick, imagem) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [id, data.nome, data.email, data.senha, data.nascimento, data.nick, data.imagem || 'default.png'],
        function (err) {
          if (err) {
            console.error("Erro ao criar usuário:", err);
            return res.status(500).json({ erro: 'Erro ao criar usuário', detalhes: err, });
          }
  
          db.get('SELECT * FROM Usuarios WHERE id = ?', [id], (err, usuario) => {
            if (err) {
              return res.status(500).json({ erro: 'Erro ao buscar usuário criado', detalhes: err });
            }
            res.status(201).json({ data: usuario });
          });
        }
      );
    } catch (err) {
      console.error("Erro durante a verificação de usuário:", err);
      res.status(500).json({ erro: 'Erro ao verificar usuário', detalhes: err});
    }
}

//Comentado Arrumado
controller.listagemusuarios = async (req, res) => {
    const search = req.query.search || '';

    try {
        const usuarios = await new Promise((resolve, reject) => {
            const query = search
                ? `SELECT id, nome, email, nick, imagem, nascimento 
                   FROM Usuarios 
                   WHERE nome LIKE ? OR nick LIKE ?`
                : `SELECT id, nome, email, nick, imagem, nascimento 
                   FROM Usuarios`;

            const params = search ? [`%${search}%`, `%${search}%`] : [];

            db.all(query, params, (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });

        res.status(200).json(usuarios);
    } catch (err) {
        console.error('Erro ao buscar usuários:', err);
        res.status(500).json({
            erro: 'Erro ao buscar usuários',
            detalhes: err.message,
        });
    }
};

//Comentado Arrumado
controller.detalhesusuarios = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        const usuario = await new Promise((resolve, reject) => {
            db.get(
                'SELECT nome, email, nick, imagem, nascimento FROM Usuarios WHERE id = ?',
                [usuario_id],
                (err, row) => {
                    if (err) return reject(err);
                    resolve(row);
                }
            );
        });

        if (!usuario) {
            return res.status(404).json({
                erro: 'Usuário não encontrado'
            });
        }

        res.status(200).json({
            data: usuario
        });
    } catch (err) {
        console.error('Erro ao buscar detalhes do usuário:', err);
        res.status(500).json({
            erro: 'Usuário não encontrado',
            detalhes: err
        });
    }
};

//Comentado Arrumado 
controller.atualizacaousuario = (req, res) => {
    const { usuario_id } = req.params;
    const newData = req.body;

    if (!newData || Object.keys(newData).length === 0) {
        return res.status(400).json({
            erro: 'Pelo menos um campo deve ser fornecido para atualização'
        });
    }

    // Conectando ao banco de dados
    db.serialize(() => {
        try {
            // Verifica email duplicado
            if (newData.email) {
                db.get(
                    'SELECT id FROM Usuarios WHERE email = ? AND id != ?',
                    [newData.email, usuario_id],
                    (err, row) => {
                        if (err) {
                            return res.status(500).json({ erro: 'Erro ao verificar email', detalhes: err });
                        }
                        if (row) {
                            return res.status(400).json({ erro: 'Email já está em uso' });
                        }
                    }
                );
            }

            // Verifica nick duplicado
            if (newData.nick) {
                db.get(
                    'SELECT id FROM Usuarios WHERE nick = ? AND id != ?',
                    [newData.nick, usuario_id],
                    (err, row) => {
                        if (err) {
                            return res.status(500).json({ erro: 'Erro ao verificar nick', detalhes: err });
                        }
                        if (row) {
                            return res.status(400).json({ erro: 'Nick já está em uso' });
                        }
                    }
                );
            }

            // Monta consulta de atualização
            let query = 'UPDATE Usuarios SET ';
            let fields = [];
            let values = [];

            if (newData.nome) {
                fields.push('nome = ?');
                values.push(newData.nome);
            }
            if (newData.email) {
                fields.push('email = ?');
                values.push(newData.email);
            }
            if (newData.senha) {
                fields.push('senha = ?');
                values.push(newData.senha);
            }
            if (newData.nascimento) {
                fields.push('nascimento = ?');
                values.push(newData.nascimento);
            }
            if (newData.nick) {
                fields.push('nick = ?');
                values.push(newData.nick);
            }
            if (newData.imagem) {
                fields.push('imagem = ?');
                values.push(newData.imagem);
            }

            query += fields.join(', ') + ' WHERE id = ?';
            values.push(usuario_id);

            // Atualiza no banco de dados
            db.run(query, values, function (err) {
                if (err) {
                    return res.status(500).json({ erro: 'Erro ao atualizar usuário', detalhes: err });
                }

                // Busca o usuário atualizado
                db.get(
                    'SELECT * FROM Usuarios WHERE id = ?',
                    [usuario_id],
                    (err, row) => {
                        if (err || !row) {
                            return res.status(404).json({ erro: 'Usuário não encontrado' });
                        }
                        res.status(200).json({ data: row });
                    }
                );
            });
        } catch (err) {
            res.status(500).json({ erro: 'Erro durante a atualização', detalhes: err });
        }
    });
};

//Comentado Arrumado
controller.novapublicacao = async (req, res) => {
    const data = req.body;

    // Verifica se todos os campos obrigatórios foram preenchidos
    if (!data.publicacao || !data.usuario_id) {
        return res.status(400).json({
            erro: 'Todos os campos são obrigatórios',
            detalhes: data
        });
    }

    try {
        // verifica se o usuário existe
        const usuario = await new Promise((resolve, reject) => {
            db.get(
                'SELECT * FROM Usuarios WHERE id = ?',
                [data.usuario_id],
                (err, row) => {
                    if (err) return reject(err);
                    resolve(row);
                }
            );
        });

        if (!usuario) {
            return res.status(400).json({
                erro: 'Usuário não encontrado.'
            });
        }

        // Adiciona aa nova publicação
        const resultado = await new Promise((resolve, reject) => {
            const id = uuidv4();
            db.run(
                'INSERT INTO Publicacoes (id, publicacao, usuario_id) VALUES (?, ?, ?)',
                [id, data.publicacao, data.usuario_id],
                function (err) {
                    if (err) return reject(err);
                    resolve({ id: id });
                }
            );
        });

        // Retorna os dados da nova publicação
        res.status(200).json({
            publicacao: data.publicacao,
            usuario_id: data.usuario_id,
            publicacao_id: resultado.id
        });
    } catch (err) {
        console.error('Erro ao criar publicação:', err);
        res.status(500).json({
            erro: 'Erro ao criar publicação',
            detalhes: err
        });
    }
};

//Comentado Arrumado
controller.listagempublicacoes = async (req, res) => {
    try {
        // Busca todas as publicações e com os dados dos usuários juntos
        const publicacoes = await Publicacoes.findAll({
            include: {
                model: Usuario,
                attributes: ["nick", "imagem"],
            },
        });

        // Formata os dados
        const data = publicacoes.map((publicacao) => ({
            publicacao_id: publicacao.id,
            publicacao: publicacao.publicacao,
            usuario_id: publicacao.usuario_id,
            nick: publicacao.Usuario.nick,
            imagem: publicacao.Usuario.imagem,
            qtd_likes: publicacao.qtd_likes,
            criado_em: publicacao.criado_em.toISOString(),
        }));

        // Retorna o resultado com sucesso
        res.status(200).json({
            data: data,
            total: publicacoes.length,
        });
    } catch (err) {
        console.error("Erro ao listar publicações:", err);
        res.status(500).json({
            erro: "Erro ao listar publicações",
            detalhes: err.message,
        });
    }
};

//Comentado Arrumado
controller.publicacoesusuario = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        // Busca as publicações do usuário no banco
        const publicacoes = await new Promise((resolve, reject) => {
            db.all(
                'SELECT * FROM Publicacoes WHERE usuario_id = ?',
                [usuario_id],
                (err, rows) => {
                    if (err) return reject(err);
                    resolve(rows);
                }
            );
        });

        // Se não tiver publicações
        if (publicacoes.length === 0) {
            return res.status(404).json({
                erro: 'Não há publicações para esse usuário'
            });
        }

        // Busca os dados do usuário
        const usuario = await new Promise((resolve, reject) => {
            db.get(
                'SELECT nick, imagem FROM Usuarios WHERE id = ?',
                [usuario_id],
                (err, row) => {
                    if (err) return reject(err);
                    if (!row) return reject('Usuário não encontrado');
                    resolve(row);
                }
            );
        });

        let qtd_comentarios = 0;

        // Busca os dados dos comentários para cada publicação
        const publicacoesComComentarios = await Promise.all(publicacoes.map(async (publicacao) => {
            // Busca os comentários dessa publicação
            const coments = await new Promise((resolve, reject) => {
                db.all(
                    'SELECT * FROM Comentarios WHERE publicacao_id = ?',
                    [publicacao.id],
                    (err, rows) => {
                        if (err) return reject(err);
                        resolve(rows);
                    }
                );
            });

            qtd_comentarios = coments.length;

            return {
                publicacao_id: publicacao.id,
                publicacao: publicacao.publicacao,
                usuario_id: publicacao.usuario_id,
                nick: usuario.nick,
                imagem: usuario.imagem,
                qtd_likes: publicacao.qtd_likes,
                qtd_comentarios: qtd_comentarios,
                criado_em: publicacao.criado_em
            };
        }));

        // Resposta de sucesso
        res.status(200).json({
            data: publicacoesComComentarios,
            total: publicacoes.length
        });
    } catch (err) {
        console.error('Erro ao buscar publicações ou usuário:', err);
        res.status(500).json({
            erro: 'Erro ao buscar publicações ou usuário',
            detalhes: err.message || err
        });
    }
};

//Comentado Arrmado
controller.publicacaocomentarios = async (req, res) => {
    const { publicacao_id } = req.params;
  
    try {
      console.log("Buscando publicação com id:", publicacao_id);
  
      // Busca a publicação específica pelo ID
      const publicacao = await Publicacoes.findByPk(publicacao_id);
      if (!publicacao) {
        return res.status(404).json({ erro: "Publicação não encontrada" });
      }
  
      // Busca os dados do usuário
      const usuario = await Usuario.findByPk(publicacao.usuario_id, {
        attributes: ["nick", "imagem"],
      });
      if (!usuario) {
        return res.status(404).json({ erro: "Usuário não encontrado" });
      }
  
      // Busca os comentários relacionados à publicação
      const comentarios = await Comentarios.findAll({
        where: { publicacao_id },
        include: {
          model: Usuario,
          attributes: ["nick", "imagem"],
        },
      });
  
      // Formatar os comentários
      const comentariosFormatados = comentarios.map((comentario) => ({
        comentario_id: comentario.id,
        comentario: comentario.comentario,
        usuario_id: comentario.usuario_id,
        nick: comentario.Usuario?.nick || "",
        imagem: comentario.Usuario?.imagem || "",
        qtd_likes: comentario.qtd_likes,
        criado_em: comentario.criado_em,
      }));
  
      // Formatar a resposta
      const dados = {
        publicacao_id: publicacao.id,
        publicacao: publicacao.publicacao,
        usuario_id: publicacao.usuario_id,
        nick: usuario.nick,
        imagem: usuario.imagem,
        qtd_likes: publicacao.qtd_likes,
        criado_em: publicacao.criado_em,
        comentarios: comentariosFormatados,
      };
  
      res.status(200).json(dados);
    } catch (err) {
      console.error("Erro ao buscar publicações ou usuário:", err);
      res.status(500).json({
        erro: "Erro ao buscar publicações ou usuário",
        detalhes: err.message || err,
      });
    }
  };
  

//Comentado Arrimado
controller.deletarpublicacao = async (req, res) => {
    const { publicacao_id } = req.body;

    console.log("Tentando deletar publicação com ID:", publicacao_id);

    try {
        const publicacao = await new Promise((resolve, reject) => {
            db.get(
                'SELECT usuario_id, publicacao, qtd_likes, criado_em FROM Publicacoes WHERE id = ?',
                [publicacao_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao executar a consulta:", err);
                        return reject(err);
                    }
                    console.log("Publicação encontrada:", row);
                    resolve(row);
                }
            );
        });

        if (!publicacao) {
            return res.status(404).json({
                erro: 'Publicação não encontrada'
            });
        }

        // Deletando a publicação encontrada
        await new Promise((resolve, reject) => {
            db.run(
                'DELETE FROM Publicacoes WHERE id = ?',
                [publicacao_id],
                (err) => {
                    if (err) {
                        console.error("Erro ao deletar publicação:", err);
                        return reject(err);
                    }
                    resolve();
                }
            );
        });

        // Retornando sucesso
        res.status(200).json({
            mensagem: 'Publicação deletada com sucesso',
            publicacao_id: publicacao_id
        });
    } catch (err) {
        console.error('Erro ao buscar ou deletar publicação:', err);
        res.status(500).json({
            erro: 'Erro ao tentar deletar a publicação',
            detalhes: err
        });
    }
};

//Comentado Arrimado
controller.comentario = async (req, res) => {
    const { usuario_id, publicacao_id, comentario } = req.body;

    console.log("Tentando criar um comentário:", req.body);

    // Verificar se os campos obrigatórios foram fornecidos
    if (!usuario_id || !publicacao_id) {
        return res.status(400).json({
            erro: 'Usuário ou publicação não encontrado/a',
            detalhes: { usuario_id, publicacao_id, comentario }
        });
    }

    if (!comentario) {
        return res.status(400).json({
            erro: 'Comentário é obrigatório',
            detalhes: { usuario_id, publicacao_id, comentario }
        });
    }

    try {
        // Verifica se o usuário existe
        const usuario = await Usuario.findByPk(usuario_id);
        if (!usuario) {
            return res.status(404).json({
                erro: 'Usuário não encontrado'
            });
        }

        // Verifica se a publicação existe
        const publicacao = await Publicacoes.findByPk(publicacao_id);
        if (!publicacao) {
            return res.status(404).json({
                erro: 'Publicação não encontrada'
            });
        }

        // Criar o comentário
        const novoComentario = await Comentarios.create({
            usuario_id,
            publicacao_id,
            comentario
        });

        // Retornar sucesso com o id do novo comentário
        res.status(201).json({
            mensagem: 'Comentário criado com sucesso',
            comentario_id: novoComentario.id
        });

    } catch (err) {
        console.error('Erro ao criar comentário:', err);
        res.status(500).json({
            erro: 'Erro ao tentar criar o comentário',
            detalhes: err.message
        });
    }
};

//Comentado Arrimado
controller.listagemcomentarios = async (req, res) => {
    // Obtem o publicacao_id da query string 
    const { publicacao_id } = req.body;

    if (!publicacao_id) {
        return res.status(400).json({
            erro: 'Publicação não informada',
        });
    }

    try {
        // Buscar todos os comentários da publicação
        const comentarios = await Comentarios.findAll({
            where: { publicacao_id },
            include: [
                {
                    model: Usuario,
                    attributes: ['id', 'nick', 'imagem'], // Selecionar apenas os campos necessários
                },
            ],
        });

        // Se não houver comentários
        if (comentarios.length === 0) {
            return res.status(404).json({
                mensagem: 'Nenhum comentário encontrado para esta publicação',
            });
        }

        // Estruturar os dados de retorno
        const listaComentarios = comentarios.map((comentario) => ({
            comentario_id: comentario.id,
            usuario_id: comentario.usuario_id,
            nick: comentario.Usuario ? comentario.Usuario.nick : 'Usuário desconhecido',
            imagem: comentario.Usuario ? comentario.Usuario.imagem : null,
            comentario: comentario.comentario,
            criado_em: comentario.criado_em ? comentario.criado_em.toISOString() : 'Data indisponível', // Ajuste da data
        }));

        // Retornar os dados
        res.status(200).json({
            data: listaComentarios,
            total: comentarios.length,
        });
    } catch (err) {
        console.error('Erro ao listar comentários:', err);
        res.status(500).json({
            erro: 'Erro ao buscar comentários',
            detalhes: err.message,
        });
    }
};

//Comentado Arrimado
controller.deletarcomentario = async (req, res) => {
    const { comentario_id } = req.body;

    console.log("Tentando deletar comentário com ID:", comentario_id);

    try {
        // Verificando se o idd é válido
        if (!comentario_id || typeof comentario_id !== 'string' || comentario_id.length !== 36) {
            console.warn("ID inválido:", comentario_id);
            return res.status(400).json({ erro: 'ID do comentário inválido' });
        }

        // Buscando o comentário no banco de dados
        const comentario = await new Promise((resolve, reject) => {
            db.get(
                'SELECT * FROM Comentarios WHERE id = ?',
                [comentario_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao executar a consulta:", err);
                        return reject(err);
                    }
                    console.log("Comentário encontrado na consulta:", row);
                    resolve(row);
                }
            );
        });

        if (!comentario) {
            console.warn(`Nenhum comentário encontrado com o ID: ${comentario_id}`);
            return res.status(404).json({ erro: 'Comentário não encontrado' });
        }

        // Deletando o comentário
        await new Promise((resolve, reject) => {
            db.run(
                'DELETE FROM Comentarios WHERE id = ?',
                [comentario_id],
                (err) => {
                    if (err) {
                        console.error("Erro ao deletar comentário:", err);
                        return reject(err);
                    }
                    console.log("Comentário deletado com sucesso, ID:", comentario_id);
                    resolve();
                }
            );
        });

        // Retornando sucesso
        res.status(200).json({
            mensagem: 'Comentário deletado com sucesso',
            publicacao_id: comentario.publicacao_id || null,
        });
    } catch (err) {
        console.error('Erro ao buscar ou deletar comentário:', err);
        res.status(500).json({
            erro: 'Erro ao tentar deletar o comentário',
            detalhes: err.message,
        });
    }
};

controller.curtidas_publicacao = async (req, res) => {
    const { publicacao_id } = req.body;

    if (!publicacao_id) {
        return res.status(400).json({
            erro: 'Todos os campos são obrigatórios'
        });
    }

    try {
        // Verificar se a publicação existe
        const publicacao = await new Promise((resolve, reject) => {
            db.get(
                'SELECT * FROM publicacoes WHERE id = ?',
                [publicacao_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar publicação:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        if (!publicacao) {
            return res.status(404).json({
                erro: 'Publicação não encontrada'
            });
        }

        await new Promise((resolve, reject) => {
            db.run(
                'UPDATE publicacoes SET qtd_likes = qtd_likes + 1 WHERE id = ?',
                [publicacao_id],
                (err) => {
                    if (err) {
                        console.error("Erro ao adicionar curtida:", err);
                        return reject(err);
                    }
                    resolve();
                }
            );
        });

        // Obtem a nova quantidade de curtidas
        const likesResult = await new Promise((resolve, reject) => {
            db.get(
                'SELECT qtd_likes FROM publicacoes WHERE id = ?',
                [publicacao_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar quantidade de curtidas", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        // Retornar a quantidade de curtidas
        res.status(200).json({
            qtd_likes: likesResult.qtd_likes
        });
    } catch (err) {
        console.error("Erro no processo de curtidas:", err);
        res.status(500).json({
            erro: 'Erro ao processar a curtida',
            detalhes: err.message
        });
    }
};

controller.deletarcurtida_publicacao = async (req, res) => {
    const { publicacao_id } = req.body;

    if (!publicacao_id) {
        return res.status(400).json({
            erro: 'Todos os campos são obrigatórios'
        });
    }

    try {
        const publicacao = await new Promise((resolve, reject) => {
            db.get(
                'SELECT * FROM publicacoes WHERE id = ?',
                [publicacao_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar publicação:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        if (!publicacao) {
            return res.status(404).json({
                erro: 'Publicação não encontrada'
            });
        }

        // Diminui a quantidade de curtidas
        await new Promise((resolve, reject) => {
            db.run(
                'UPDATE publicacoes SET qtd_likes = qtd_likes - 1 WHERE id = ?',
                [publicacao_id],
                (err) => {
                    if (err) {
                        console.error("Erro ao deletar curtida:", err);
                        return reject(err);
                    }
                    resolve();
                }
            );
        });

        // Obtem a nova quantidade de curtidas
        const likesResult = await new Promise((resolve, reject) => {
            db.get(
                'SELECT qtd_likes FROM publicacoes WHERE id = ?',
                [publicacao_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar quantidade de curtidas:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        // Retornar a nova quantidade de curtidas
        res.status(200).json({
            qtd_likes: likesResult.qtd_likes
        });
    } catch (err) {
        console.error("Erro ao deletar curtida:", err);
        res.status(500).json({
            erro: 'Erro ao processar a remoção da curtida',
            detalhes: err.message
        });
    }
};

controller.curtidas_comentario = async (req, res) => {
    const { comentario_id } = req.body;

    // Validação do ID do comentário
    if (!comentario_id) {
        return res.status(400).json({
            erro: 'Todos os campos são obrigatórios'
        });
    }

    try {
        // Verificar se o comentário existe
        const comentario = await new Promise((resolve, reject) => {
            db.get(
                'SELECT * FROM comentarios WHERE id = ?',
                [comentario_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar comentário:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        if (!comentario) {
            return res.status(404).json({
                erro: 'Comentário não encontrado'
            });
        }

        // Aumneta a quantidade de curtidas
        await new Promise((resolve, reject) => {
            db.run(
                'UPDATE comentarios SET qtd_likes = qtd_likes + 1 WHERE id = ?',
                [comentario_id],
                (err) => {
                    if (err) {
                        console.error("Erro ao adicionar curtida:", err);
                        return reject(err);
                    }
                    resolve();
                }
            );
        });

        // Obtem a nova quantidade de curtidas
        const likesResult = await new Promise((resolve, reject) => {
            db.get(
                'SELECT qtd_likes FROM comentarios WHERE id = ?',
                [comentario_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar quantidade de curtidas:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        res.status(200).json({
            qtd_likes: likesResult.qtd_likes
        });
    } catch (err) {
        console.error("Erro no processo de curtidas:", err);
        res.status(500).json({
            erro: 'Erro ao processar a curtida',
            detalhes: err.message
        });
    }
};

controller.deletarcurtida_comentario = async (req, res) => {
    const { comentario_id } = req.body;

    // Validação de entrada
    if (!comentario_id) {
        return res.status(400).json({
            erro: 'Todos os campos são obrigatórios'
        });
    }

    try {
        // Verificar se o comentário existe
        const comentario = await new Promise((resolve, reject) => {
            db.get(
                'SELECT * FROM comentarios WHERE id = ?',
                [comentario_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar comentário:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        if (!comentario) {
            return res.status(404).json({
                erro: 'Comentário não encontrado'
            });
        }

        // Atualiza curtidas do comentário
        await new Promise((resolve, reject) => {
            db.run(
                'UPDATE comentarios SET qtd_likes = qtd_likes - 1 WHERE id = ?',
                [comentario_id],
                (err) => {
                    if (err) {
                        console.error("Erro ao atualizar curtidas:", err);
                        return reject(err);
                    }
                    resolve();
                }
            );
        });

        // Obter a nova quantidade de curtidas
        const likesResult = await new Promise((resolve, reject) => {
            db.get(
                'SELECT qtd_likes FROM comentarios WHERE id = ?',
                [comentario_id],
                (err, row) => {
                    if (err) {
                        console.error("Erro ao buscar quantidade de curtidas:", err);
                        return reject(err);
                    }
                    resolve(row);
                }
            );
        });

        res.status(200).json({
            qtd_likes: likesResult.qtd_likes
        });
    } catch (err) {
        console.error("Erro ao processar a requisição:", err);
        res.status(500).json({
            erro: 'Erro ao processar a requisição',
            detalhes: err.message
        });
    }
};

controller.seguidores = async (req, res) => {
    const { usuario_id, usuario_a_seguir_id } = req.body;

    // Verifica se todos os campos obrigatórios foram fornecidos
    if (!usuario_id || !usuario_a_seguir_id) {
        return res.status(400).json({ erro: "Todos os campos são obrigatórios" });
    }

    // Verifica se o usuário está tentando seguir a si mesmo
    if (usuario_id === usuario_a_seguir_id) {
        return res.status(400).json({ erro: "Você não pode seguir a si mesmo" });
    }

    try {
        // Verifica se o usuário a ser seguido existe
        const usuarioASeguir = await Usuario.findByPk(usuario_a_seguir_id);
        if (!usuarioASeguir) {
            return res.status(400).json({ erro: "Usuário a ser seguido não encontrado" });
        }

        // Verifica se já existe um relacionamento
        const jaSegue = await Seguidores.findOne({
            where: {
                usuario_id: usuario_a_seguir_id, // quem está sendo seguido
                seguidor_id: usuario_id,         // Quem está seguindo
            },
        });

        if (jaSegue) {
            return res.status(400).json({ erro: "Você já segue este usuário" });
        }

        // Cria o novo relacionamento de seguidores
        const novoSeguidor = await Seguidores.create({
            usuario_id: usuario_a_seguir_id, // quem está sendo seguido
            seguidor_id: usuario_id,         // Quem está seguindo
        })

        // Retorna o ID do relacionamento criado
        res.status(201).json({ seguidor_id: novoSeguidor.seguidor_id });
    } catch (err) {
        console.error("Erro ao seguir usuário:", err);
        res.status(500).json({ erro: "Erro ao seguir usuário", detalhes: err.message });
    }
};

controller.deletarseguidor = async (req, res) => {
    const { usuario_id, usuario_a_seguir_id } = req.body;

    if (!usuario_id || !usuario_a_seguir_id) {
        return res.status(400).json({ erro: "Todos os campos são obrigatórios" });
    }

    try {
        // Verifica se o relacionamento de seguir existe
        const seguidor = await Seguidores.findOne({
            where: {
                usuario_id: usuario_a_seguir_id, // Usuário que está sendo seguido
                seguidor_id: usuario_id,         // Quem está seguindo
            },
        });

        if (!seguidor) {
            return res.status(400).json({ erro: "Você não segue este usuário" });
        }

        // Deleta o relacionamento de seguidor
        await seguidor.destroy();

        // Retorna o ID do seguidor que foi removido
        res.status(200).json({ seguidor_id: seguidor.usuario_id });
    } catch (err) {
        console.error("Erro ao deixar de seguir usuário:", err);
        res.status(500).json({ erro: "Erro ao deixar de seguir usuário", detalhes: err.message });
    }
};

controller.listagemseguidores = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        let seguidores = [];  

        seguidores = await new Promise((resolve, reject) => {
            db.all(  
                'SELECT seguidor_id FROM seguidores WHERE usuario_id = ?',
                [usuario_id],
                (err, rows) => {  
                    if (err) return reject(err);
                    if (!rows || rows.length === 0) return reject('Usuários não encontrados');

                    resolve(rows);  
                }
            );
        });

        let data = []; 

        for (let i = 0; i < seguidores.length; i++) {
            try {
                let usuarios = {};  

                usuarios = await new Promise((resolve, reject) => {
                    db.get(
                        'SELECT nome, nick, imagem FROM usuarios WHERE id = ?',
                        [seguidores[i].seguidor_id],  
                        (err, row) => {
                            if (err) return reject(err);
                            if (!row) return reject('Usuário não encontrado');

                            resolve(row);
                        }
                    );
                });

                data.push({
                    seguidor_id: seguidores[i].seguidor_id,
                    nome: usuarios.nome,
                    nick: usuarios.nick,
                    imagem: usuarios.imagem
                });

            } catch (err) {
                console.error(`Erro ao buscar informações do seguidor`, err);
                return res.status(500).json({
                    erro: 'Erro ao buscar informações do seguidor',
                    detalhes: err
                });
            }
        }

        res.status(200).json({
            data: data,
            total: seguidores.length
        });

    } catch (err) {
        console.error(`Erro ao buscar seguidores`, err);
        return res.status(500).json({
            erro: 'Erro ao buscar seguidores',
            detalhes: err
        });
    }
};

controller.seguindo = async (req, res) => {
    const { usuario_id } = req.params;

    try {
        let seguidores = [];  

        seguidores = await new Promise((resolve, reject) => {
            db.all(  
                'SELECT usuario_id FROM seguidores WHERE seguidor_id = ?',
                [usuario_id],
                (err, rows) => {  
                    if (err) return reject(err);
                    if (!rows || rows.length === 0) return reject('Usuários não encontrados');

                    resolve(rows);  
                }
            );
        });

        let data = []; 

        for (let i = 0; i < seguidores.length; i++) {
            try {
                let usuarios = {};  

                usuarios = await new Promise((resolve, reject) => {
                    db.get(
                        'SELECT nome, nick, imagem FROM usuarios WHERE id = ?',
                        [seguidores[i].usuario_id],  
                        (err, row) => {
                            if (err) return reject(err);
                            if (!row) return reject('Usuário não encontrado');

                            resolve(row);
                        }
                    );
                });

                data.push({
                    usuario_id: seguidores[i].usuario_id,
                    nome: usuarios.nome,
                    nick: usuarios.nick,
                    imagem: usuarios.imagem
                });

            } catch (err) {
                console.error(`"Erro ao buscar usuários seguidos`, err);
                return res.status(500).json({
                    erro: '"Erro ao buscar usuários seguidos',
                    detalhes: err
                });
            }
        }

        res.status(200).json({
            data: data,
            total: seguidores.length
        });

    } catch (err) {
        console.error(`"Erro ao buscar usuário`, err);
        return res.status(500).json({
            erro: '"Erro ao buscar usuário',
            detalhes: err
        });
    }
};

export default controller;
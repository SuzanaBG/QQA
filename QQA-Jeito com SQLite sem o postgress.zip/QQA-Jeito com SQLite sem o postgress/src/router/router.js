import express from 'express';
const router = express.Router();
import crud from '../controller/crud.js';

router.post('/usuarios', crud.usuario);
router.get('/usuarios', crud.listagemusuarios);
router.get('/usuarios/:usuario_id', crud.detalhesusuarios);
router.patch('/usuarios/:usuario_id', crud.atualizacaousuario);
router.post('/publicacoes', crud.novapublicacao);
router.get('/publicacoes', crud.listagempublicacoes)
router.get('/publicacoes/de/:usuario_id', crud.publicacoesusuario);
router.get('/publicacoes/:publicacao_id', crud.publicacaocomentarios);
router.delete('/publicacoes', crud.deletarpublicacao);
router.post('/comentarios', crud.comentario);
router.get('/comentarios', crud.listagemcomentarios);
router.delete('/comentarios', crud.deletarcomentario);
router.post('/curtidas/publicacao', crud.curtidas_publicacao);
router.delete('/curtidas/publicacao', crud.deletarcurtida_publicacao);
router.post('/curtidas/comentario', crud.curtidas_comentario);
router.delete('/curtidas/comentario', crud.deletarcurtida_comentario);
router.post('/seguidores', crud.seguidores);
router.delete('/seguidores', crud.deletarseguidor);
router.get('/seguidores/:usuario_id', crud.listagemseguidores);
router.get('/seguidores/seguindo/:usuario_id', crud.seguindo);

router.get('/', (req, res) => {
    res.redirect('/index'); 
});

export default router;
